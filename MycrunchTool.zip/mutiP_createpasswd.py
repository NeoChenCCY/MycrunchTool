#多執行序的程式碼 : 同時執行多個程式檔案，同步執行的概念
#此程式會透過命令視窗(CMD)，呼叫python程式去各自獨立執行不同的程式檔案(.py)

import os multiprocessing

def worker(file):
    programcmd = 'python '
    executionFile = file

    res ="state : "
    res2 = os.system(programcmd + executionFile)
    res2 >>= 8
    res += str(res2)

    print(res)

if __name__ == '__main__':
    #program execute files
    #【format】path + filename or filename
    files = ["createpasswdlist8.py","createpasswdlist9.py","createpasswdlist10.py","createpasswdlist11.py","createpasswdlist12.py"]
    
    for i in files:
        p = multiprocessing.Process(target=worker, args=(i,))
        p.start()
        p.join()
